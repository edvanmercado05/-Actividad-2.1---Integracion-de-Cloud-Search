module.exports = {
  presets: [
    '@vue/app',
    '@babel/preset-env'
  ]
}
